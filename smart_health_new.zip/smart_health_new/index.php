<?php
include("config.php");

$msg = "";

if (isset($_POST['send'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    mysqli_query($conn, "INSERT INTO contact (name, email, message)
    VALUES ('$name','$email','$message')");

    $msg = "Message Sent Successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Smart Health</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
body {
    margin:0;
    font-family: 'Segoe UI';
    background: #0b1f3a;
    color:white;
    overflow-x:hidden;
}

/* 🔷 PARTICLE BACKGROUND */
#particles-js {
    position:fixed;
    width:100%;
    height:100%;
    z-index:-1;
}

/* NAVBAR */
.navbar {
    background: rgba(0,123,255,0.3);
    backdrop-filter: blur(10px);
}

/* HERO */
.hero {
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    flex-direction:column;
    text-align:center;
}

.title {
    font-size:50px;
    font-weight:bold;
    background: linear-gradient(to right,#00c6ff,#0072ff);
    -webkit-background-clip:text;
    color:transparent;
    animation: glow 2s infinite alternate;
}

@keyframes glow {
    from { text-shadow:0 0 10px #00c6ff; }
    to { text-shadow:0 0 25px #0072ff; }
}

/* GLASS CARD */
.glass {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(15px);
    border-radius:15px;
    padding:20px;
    transition:0.3s;
}

.glass:hover {
    transform:translateY(-10px) scale(1.03);
}

/* BUTTON */
.btn-custom {
    background: linear-gradient(to right,#00c6ff,#0072ff);
    color:white;
    border-radius:30px;
}

/* STATS */
.stats h2 {
    font-size:40px;
    color:#00c6ff;
}

/* CONTACT */
input, textarea {
    border-radius:10px !important;
}

/* FOOTER */
footer {
    background:#007bff;
    padding:10px;
    text-align:center;
}
</style>
</head>

<body>

<div id="particles-js"></div>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg">
<div class="container">
<a class="navbar-brand text-white">💙 Smart Health</a>
<div class="ms-auto">
<a href="user/register.php" class="nav-link d-inline text-white">Register</a>
<a href="user/login.php" class="nav-link d-inline text-white">User</a>
<a href="doctor/login.php" class="nav-link d-inline text-white">Doctor</a>
<a href="admin/login.php" class="nav-link d-inline text-white">Admin</a>
</div>
</div>
</nav>

<!-- HERO -->
<div class="hero">
    <div class="title">Smart Health Advisory System</div>
    <p>Your Health, Our Priority 💙</p>
    <a href="user/register.php" class="btn btn-custom mt-3">Get Started</a>
</div>

<!-- FEATURES -->
<div class="container my-5">
    <h3 class="text-center">Our Features</h3>
<div class="row text-center">

<div class="col-md-4" data-aos="zoom-in">
<div class="glass">
<i class="fa fa-stethoscope fa-2x"></i>
<h5>Check Symptoms</h5>
</div>
</div>

<div class="col-md-4" data-aos="zoom-in">
<div class="glass">
<i class="fa fa-user-doctor fa-2x"></i>
<h5>Find Doctors</h5>
</div>
</div>

<div class="col-md-4" data-aos="zoom-in">
<div class="glass">
<i class="fa fa-calendar fa-2x"></i>
<h5>Book Appointment</h5>
</div>
</div>

</div>
</div>

<!-- STATS -->
<div class="container stats text-center my-5">
<div class="row">

<div class="col-md-4">
<h2>50+</h2>
<p>Doctors</p>
</div>

<div class="col-md-4">
<h2>200+</h2>
<p>Patients</p>
</div>

<div class="col-md-4">
<h2>300+</h2>
<p>Appointments</p>
</div>

</div>
</div>

<!-- DOCTORS -->
<div class="container my-5">
<h3 class="text-center">Our Doctors</h3>
<div class="row">

<?php
$res = mysqli_query($conn, "SELECT * FROM doctors LIMIT 3");
while($row = mysqli_fetch_assoc($res)) {
?>
<div class="col-md-4">
<div class="glass text-center">
<h5><?php echo $row['name']; ?></h5>
<p><?php echo $row['specialization']; ?></p>
</div>
</div>
<?php } ?>

</div>
</div>

<!-- CONTACT -->
<div class="container my-5">
<h3 class="text-center">Contact Us</h3>

<?php if($msg) { ?>
<div class="alert alert-success"><?php echo $msg; ?></div>
<?php } ?>

<form method="POST" class="glass">

<input type="text" name="name" class="form-control mb-3" placeholder="Your Name" required>
<input type="email" name="email" class="form-control mb-3" placeholder="Your Email" required>
<textarea name="message" class="form-control mb-3" placeholder="Message"></textarea>

<button name="send" class="btn btn-custom w-100">Send Message</button>

</form>
</div>

<footer>
© 2026 Smart Health Advisory System
</footer>

<!-- JS -->
<script src="https://cdn.jsdelivr.net/npm/particles.js"></script>
<script>
particlesJS("particles-js", {
  particles: { number: { value: 80 }, size: { value: 3 } }
});
</script>

<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>
AOS.init();
</script>

</body>
</html>