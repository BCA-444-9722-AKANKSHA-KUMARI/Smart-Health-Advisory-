<?php
// config.php

$servername = "localhost";
$username = "root";
$password = "";
$database = "smart_health_new";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Optional: Set timezone (India)
date_default_timezone_set("Asia/Kolkata");
?>