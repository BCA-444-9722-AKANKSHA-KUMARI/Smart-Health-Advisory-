<?php
session_start();
include("../config.php");

$message = "";

if (isset($_POST['login'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM doctors 
    WHERE username='$username' AND password='$password'");

    if (mysqli_num_rows($query) > 0) {

        $row = mysqli_fetch_assoc($query);

        $_SESSION['doctor_id'] = $row['doctor_id'];
        $_SESSION['doctor_name'] = $row['name'];

        header("Location: dashboard.php");
        exit();

    } else {
        $message = "Invalid Login!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Doctor Login</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(135deg, #1e3a8a, #2563eb);
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}
.box {
    background:white;
    padding:30px;
    border-radius:10px;
    width:350px;
}
</style>

</head>
<body>

<div class="box">

<h3 class="text-center mb-3">👨‍⚕️ Doctor Login</h3>

<?php if($message){ ?>
<div class="alert alert-danger"><?php echo $message; ?></div>
<?php } ?>

<form method="POST">

<input type="text" name="username" class="form-control mb-3" placeholder="Username" required>

<input type="password" name="password" class="form-control mb-3" placeholder="Password" required>

<button name="login" class="btn btn-primary w-100">Login</button>

</form>

</div>

</body>
</html>