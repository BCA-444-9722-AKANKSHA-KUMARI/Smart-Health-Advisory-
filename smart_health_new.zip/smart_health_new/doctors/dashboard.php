<?php
session_start();
include("../config.php");

if (!isset($_SESSION['doctor_id'])) {
    header("Location: login.php");
    exit();
}

$doctor_id = $_SESSION['doctor_id'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Doctor Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(135deg, #1e3a8a, #2563eb);
}
.box {
    background:white;
    padding:25px;
    margin-top:40px;
    border-radius:10px;
}
</style>

</head>

<body>

<div class="container">

<div class="box">

<h3 class="text-center mb-4">👨‍⚕️ Doctor Dashboard</h3>

<table class="table table-bordered text-center">

<thead class="table-primary">
<tr>
<th>Patient Name</th>
<th>Date</th>
<th>Status</th>
</tr>
</thead>

<tbody>

<?php
$query = "
SELECT a.*, u.name as patient_name
FROM appointments a
JOIN users u ON a.user_id = u.user_id
WHERE a.doctor_id = '$doctor_id'
ORDER BY a.appointment_id DESC
";

$result = mysqli_query($conn, $query);

while($row = mysqli_fetch_assoc($result)){
?>

<tr>
<td><?php echo $row['patient_name']; ?></td>
<td><?php echo $row['appointment_date']; ?></td>
<td><?php echo $row['status']; ?></td>
</tr>

<?php } ?>

</tbody>

</table>

<a href="../logout.php" class="btn btn-danger">Logout</a>

</div>

</div>

</body>
</html>