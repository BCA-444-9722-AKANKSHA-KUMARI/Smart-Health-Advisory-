<?php
session_start();
include("../config.php");

// 🔐 Check admin login
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

// ➕ Add Doctor
if (isset($_POST['add'])) {

    $name = $_POST['name'];
    $specialization = $_POST['specialization'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];

    $query = "INSERT INTO doctors (name, specialization, phone, email)
              VALUES ('$name', '$specialization', '$phone', '$email')";

    mysqli_query($conn, $query);
}

// ❌ Delete Doctor
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM doctors WHERE doctor_id = $id");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Doctors</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

        body {
            background: linear-gradient(135deg, #1e3a8a, #2563eb);
            min-height: 100vh;
        }

        /* Navbar */
        .navbar {
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(10px);
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 22px;
            color: #fff !important;
        }

        /* Box */
        .box {
            background: #ffffff;
            padding: 25px;
            margin-top: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        /* Button */
        .btn-success {
            border-radius: 20px;
        }

        .btn-secondary {
            border-radius: 20px;
        }

        /* Table hover */
        table tbody tr:hover {
            background: #f1f5f9;
        }

    </style>
</head>

<body>

<!-- 🔝 Navbar -->
<nav class="navbar navbar-dark">
    <div class="container">
        <span class="navbar-brand">🩺 Smart Health System</span>
    </div>
</nav>

<div class="container">

    <div class="box">

        <h3 class="text-center mb-4 text-primary">👨‍⚕️ Manage Doctors</h3>

        <!-- ➕ Add Doctor Form -->
        <form method="POST">
            <div class="row g-2">

                <div class="col-md-3">
                    <input type="text" name="name" class="form-control" placeholder="Doctor Name" required>
                </div>

                <div class="col-md-3">
                    <input type="text" name="specialization" class="form-control" placeholder="Specialization" required>
                </div>

                <div class="col-md-2">
                    <input type="text" name="phone" class="form-control" placeholder="Phone" required>
                </div>

                <div class="col-md-3">
                    <input type="email" name="email" class="form-control" placeholder="Email" required>
                </div>

                <div class="col-md-1">
                    <button type="submit" name="add" class="btn btn-success w-100">Add</button>
                </div>

            </div>
        </form>

        <hr>

        <!-- 📋 Doctor List -->
        <table class="table table-bordered text-center mt-3">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Specialization</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

            <?php
            $result = mysqli_query($conn, "SELECT * FROM doctors ORDER BY doctor_id DESC");

            while ($row = mysqli_fetch_assoc($result)) {
            ?>

                <tr>
                    <td><?php echo $row['doctor_id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['specialization']; ?></td>
                    <td><?php echo $row['phone']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td>
                        <a href="?delete=<?php echo $row['doctor_id']; ?>" 
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Delete this doctor?')">
                           Delete
                        </a>
                    </td>
                </tr>

            <?php } ?>

            </tbody>
        </table>

        <div class="text-center">
            <a href="dashboard.php" class="btn btn-secondary">Back</a>
        </div>

    </div>

</div>

</body>
</html>