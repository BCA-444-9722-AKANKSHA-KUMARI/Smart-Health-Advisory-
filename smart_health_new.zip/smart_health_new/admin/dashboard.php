<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

/* 🌈 Animated Background */
body {
    background: linear-gradient(-45deg, #dbeafe, #bfdbfe, #93c5fd, #60a5fa);
    background-size: 400% 400%;
    animation: bgMove 10s ease infinite;
}

@keyframes bgMove {
    0% {background-position: 0% 50%;}
    50% {background-position: 100% 50%;}
    100% {background-position: 0% 50%;}
}

/* Fade In */
.fade-in {
    animation: fadeIn 1s ease-in;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Buttons Animation */
.btn {
    transition: 0.3s;
    border-radius: 25px;
}

.btn:hover {
    transform: scale(1.05);
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
}

/* Navbar Shadow */
.navbar {
    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
}

</style>

</head>

<body>

<nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <span class="navbar-brand">Admin Panel</span>
        <a href="logout.php" class="btn btn-light">Logout</a>
    </div>
</nav>

<div class="container mt-5 fade-in">

    <h2 class="text-center mb-4">Admin Dashboard</h2>

    <div class="row text-center">

        <div class="col-md-4 mb-3">
            <a href="manage_doctors.php" class="btn btn-primary w-100">Manage Doctors</a>
        </div>

        <div class="col-md-4 mb-3">
            <a href="manage_diseases.php" class="btn btn-success w-100">Manage Diseases</a>
        </div>

        <div class="col-md-4 mb-3">
            <a href="manage_symptoms.php" class="btn btn-warning w-100">Manage Symptoms</a>
        </div>

        <div class="col-md-4 mb-3">
            <a href="manage_mapping.php" class="btn btn-info w-100">Map Disease & Symptoms</a>
        </div>

        <div class="col-md-4 mb-3">
            <a href="manage_appointments.php" class="btn btn-danger w-100">Manage Appointments</a>
        </div>

    </div>

</div>

</body>
</html>