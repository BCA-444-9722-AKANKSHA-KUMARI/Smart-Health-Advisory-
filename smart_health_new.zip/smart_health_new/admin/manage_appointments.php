<?php
session_start();
include("../config.php");

// 🔐 Check admin login
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

// ✅ Approve Appointment
if (isset($_GET['approve'])) {
    $id = $_GET['approve'];
    mysqli_query($conn, "UPDATE appointments SET status='Approved' WHERE appointment_id=$id");
}

// ❌ Reject Appointment
if (isset($_GET['reject'])) {
    $id = $_GET['reject'];
    mysqli_query($conn, "UPDATE appointments SET status='Rejected' WHERE appointment_id=$id");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Appointments</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body { background: #f4f6f9; }
        .box {
            background: white;
            padding: 20px;
            margin-top: 30px;
            border-radius: 10px;
        }
    </style>
</head>

<body>

<div class="container">

    <div class="box">

        <h3 class="text-center mb-4">Manage Appointments</h3>

        <table class="table table-bordered text-center">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Doctor</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

            <?php
            $query = "
            SELECT a.*, u.name AS user_name, d.name AS doctor_name
            FROM appointments a
            JOIN users u ON a.user_id = u.user_id
            JOIN doctors d ON a.doctor_id = d.doctor_id
            ORDER BY a.appointment_id DESC
            ";

            $result = mysqli_query($conn, $query);

            while ($row = mysqli_fetch_assoc($result)) {
            ?>

                <tr>
                    <td><?php echo $row['appointment_id']; ?></td>
                    <td><?php echo $row['user_name']; ?></td>
                    <td><?php echo $row['doctor_name']; ?></td>
                    <td><?php echo $row['appointment_date']; ?></td>

                    <td>
                        <?php
                        if ($row['status'] == "Approved") {
                            echo "<span class='badge bg-success'>Approved</span>";
                        } elseif ($row['status'] == "Rejected") {
                            echo "<span class='badge bg-danger'>Rejected</span>";
                        } else {
                            echo "<span class='badge bg-warning text-dark'>Pending</span>";
                        }
                        ?>
                    </td>

                    <td>
                        <?php if ($row['status'] == "Pending") { ?>
                            <a href="?approve=<?php echo $row['appointment_id']; ?>" class="btn btn-success btn-sm">Approve</a>
                            <a href="?reject=<?php echo $row['appointment_id']; ?>" class="btn btn-danger btn-sm">Reject</a>
                        <?php } else {
                            echo "-";
                        } ?>
                    </td>
                </tr>

            <?php } ?>

            </tbody>
        </table>

        <div class="text-center">
            <a href="dashboard.php" class="btn btn-secondary">Back</a>
        </div>

    </div>

</div>

</body>
</html>