<?php
session_start();
include("../config.php");

// 🔐 Check admin login
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

// ➕ Add Disease
if (isset($_POST['add'])) {

    $name = $_POST['disease_name'];
    $description = $_POST['description'];
    $precautions = $_POST['precautions'];

    $query = "INSERT INTO diseases (disease_name, description, precautions)
              VALUES ('$name', '$description', '$precautions')";

    mysqli_query($conn, $query);
}

// ❌ Delete Disease
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM diseases WHERE disease_id = $id");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Diseases</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

        body {
            background: linear-gradient(135deg, #1e3a8a, #2563eb);
            min-height: 100vh;
        }

        /* Navbar */
        .navbar {
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(10px);
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 22px;
            color: #fff !important;
        }

        /* Box */
        .box {
            background: white;
            padding: 25px;
            margin-top: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        /* Table hover */
        table tbody tr:hover {
            background: #f1f5f9;
        }

    </style>
</head>

<body>

<!-- 🔝 Navbar -->
<nav class="navbar navbar-dark">
    <div class="container">
        <span class="navbar-brand">🩺 Smart Health System</span>
    </div>
</nav>

<div class="container">

    <div class="box">

        <h3 class="text-center mb-4 text-primary">🦠 Manage Diseases</h3>

        <!-- ➕ Add Disease Form -->
        <form method="POST">
            <div class="row g-2">

                <div class="col-md-3">
                    <input type="text" name="disease_name" class="form-control" placeholder="Disease Name" required>
                </div>

                <div class="col-md-3">
                    <input type="text" name="description" class="form-control" placeholder="Description" required>
                </div>

                <div class="col-md-4">
                    <input type="text" name="precautions" class="form-control" placeholder="Precautions" required>
                </div>

                <div class="col-md-2">
                    <button type="submit" name="add" class="btn btn-success w-100">Add</button>
                </div>

            </div>
        </form>

        <hr>

        <!-- 📋 Disease List -->
        <table class="table table-bordered text-center mt-3">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Disease</th>
                    <th>Description</th>
                    <th>Precautions</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

            <?php
            $result = mysqli_query($conn, "SELECT * FROM diseases ORDER BY disease_id DESC");

            while ($row = mysqli_fetch_assoc($result)) {
            ?>

                <tr>
                    <td><?php echo $row['disease_id']; ?></td>
                    <td><?php echo $row['disease_name']; ?></td>
                    <td><?php echo $row['description']; ?></td>
                    <td><?php echo $row['precautions']; ?></td>
                    <td>
                        <a href="?delete=<?php echo $row['disease_id']; ?>" 
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Delete this disease?')">
                           Delete
                        </a>
                    </td>
                </tr>

            <?php } ?>

            </tbody>
        </table>

        <div class="text-center">
            <a href="dashboard.php" class="btn btn-secondary">Back</a>
        </div>

    </div>

</div>

</body>
</html>