<?php
session_start();
include("../config.php");

$message = "";

if (isset($_POST['login'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM admin WHERE username='$username' AND password='$password'");

    if (mysqli_num_rows($query) > 0) {
        $_SESSION['admin'] = $username;
        header("Location: dashboard.php");
        exit();
    } else {
        $message = "Invalid Login!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

/* 🌈 Animated Gradient Background */
body {
    margin: 0;
    height: 100vh;
    background: linear-gradient(-45deg, #0f172a, #1e3a8a, #2563eb, #38bdf8);
    background-size: 400% 400%;
    animation: bgMove 10s ease infinite;
    display: flex;
    flex-direction: column;
}

/* Animation */
@keyframes bgMove {
    0% {background-position: 0% 50%;}
    50% {background-position: 100% 50%;}
    100% {background-position: 0% 50%;}
}

/* Navbar */
.navbar {
    background: rgba(0,0,0,0.6);
    backdrop-filter: blur(10px);
}

.navbar-brand {
    font-size: 22px;
    font-weight: bold;
}

/* Center Container */
.main-container {
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;
}

/* Login Box */
.login-box {
    width: 360px;
    padding: 40px;
    border-radius: 20px;
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(15px);
    color: white;
    box-shadow: 0 10px 30px rgba(0,0,0,0.4);
    animation: floatBox 3s ease-in-out infinite;
}

/* Floating effect */
@keyframes floatBox {
    0%,100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}

/* Input */
.form-control {
    background: transparent;
    color: white;
    border: 1px solid white;
}

.form-control::placeholder {
    color: #ddd;
}

/* Button */
.btn-login {
    width: 100%;
    border-radius: 25px;
    background: #fff;
    color: #000;
    font-weight: bold;
    transition: 0.3s;
}

.btn-login:hover {
    background: #ddd;
    transform: scale(1.05);
}

/* Icon */
.icon {
    position: absolute;
    right: 15px;
    top: 10px;
    cursor: pointer;
}

/* Input group */
.input-group {
    position: relative;
}

/* Error */
.alert {
    padding: 8px;
    text-align: center;
}

</style>

</head>

<body>

<!-- 🔝 Navbar -->
<nav class="navbar navbar-dark">
    <div class="container">
        <span class="navbar-brand">🩺 Smart Health System - Admin</span>
    </div>
</nav>

<!-- 🔐 Login Section -->
<div class="main-container">

<div class="login-box">

<h3 class="text-center mb-4">🔐 Admin Login</h3>

<?php if($message) { ?>
<div class="alert alert-danger"><?php echo $message; ?></div>
<?php } ?>

<form method="POST">

    <div class="mb-3">
        <input type="text" name="username" class="form-control" placeholder="Username" required>
    </div>

    <div class="mb-3 input-group">
        <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
        <i class="fa fa-eye icon" onclick="togglePassword()"></i>
    </div>

    <button name="login" class="btn btn-login">Login</button>

</form>

</div>

</div>

<script>
function togglePassword() {
    var x = document.getElementById("password");
    x.type = (x.type === "password") ? "text" : "password";
}
</script>

</body>
</html>