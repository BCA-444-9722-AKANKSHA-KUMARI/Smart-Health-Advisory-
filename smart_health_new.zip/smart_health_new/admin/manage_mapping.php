<?php
session_start();
include("../config.php");

// 🔐 Check admin login
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

// ➕ Add Mapping
if (isset($_POST['add'])) {

    $disease_id = $_POST['disease_id'];
    $symptom_id = $_POST['symptom_id'];

    $query = "INSERT INTO disease_symptom (disease_id, symptom_id)
              VALUES ('$disease_id', '$symptom_id')";

    mysqli_query($conn, $query);
}

// ❌ Delete Mapping
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM disease_symptom WHERE id = $id");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Mapping</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

        body {
            background: linear-gradient(135deg, #1e3a8a, #2563eb);
            min-height: 100vh;
        }

        /* Navbar */
        .navbar {
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(10px);
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 22px;
            color: #fff !important;
        }

        /* Box */
        .box {
            background: white;
            padding: 25px;
            margin-top: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        /* Table hover */
        table tbody tr:hover {
            background: #f1f5f9;
        }

    </style>
</head>

<body>

<!-- 🔝 Navbar -->
<nav class="navbar navbar-dark">
    <div class="container">
        <span class="navbar-brand">🩺 Smart Health System</span>
    </div>
</nav>

<div class="container">

    <div class="box">

        <h3 class="text-center mb-4 text-primary">🔗 Map Disease & Symptoms</h3>

        <!-- ➕ Mapping Form -->
        <form method="POST">
            <div class="row">

                <!-- Disease Dropdown -->
                <div class="col-md-5">
                    <select name="disease_id" class="form-control" required>
                        <option value="">-- Select Disease --</option>

                        <?php
                        $diseases = mysqli_query($conn, "SELECT * FROM diseases");

                        while ($row = mysqli_fetch_assoc($diseases)) {
                        ?>
                            <option value="<?php echo $row['disease_id']; ?>">
                                <?php echo $row['disease_name']; ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>

                <!-- Symptom Dropdown -->
                <div class="col-md-5">
                    <select name="symptom_id" class="form-control" required>
                        <option value="">-- Select Symptom --</option>

                        <?php
                        $symptoms = mysqli_query($conn, "SELECT * FROM symptoms");

                        while ($row = mysqli_fetch_assoc($symptoms)) {
                        ?>
                            <option value="<?php echo $row['symptom_id']; ?>">
                                <?php echo $row['symptom_name']; ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>

                <div class="col-md-2">
                    <button type="submit" name="add" class="btn btn-success w-100">
                        Add
                    </button>
                </div>

            </div>
        </form>

        <hr>

        <!-- 📋 Mapping List -->
        <table class="table table-bordered text-center mt-3">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Disease</th>
                    <th>Symptom</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

            <?php
            $query = "
            SELECT ds.id, d.disease_name, s.symptom_name
            FROM disease_symptom ds
            JOIN diseases d ON ds.disease_id = d.disease_id
            JOIN symptoms s ON ds.symptom_id = s.symptom_id
            ORDER BY ds.id DESC
            ";

            $result = mysqli_query($conn, $query);

            while ($row = mysqli_fetch_assoc($result)) {
            ?>

                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['disease_name']; ?></td>
                    <td><?php echo $row['symptom_name']; ?></td>
                    <td>
                        <a href="?delete=<?php echo $row['id']; ?>" 
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Delete mapping?')">
                           Delete
                        </a>
                    </td>
                </tr>

            <?php } ?>

            </tbody>
        </table>

        <div class="text-center">
            <a href="dashboard.php" class="btn btn-secondary">Back</a>
        </div>

    </div>

</div>

</body>
</html>