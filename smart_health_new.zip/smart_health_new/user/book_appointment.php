<?php
session_start();
include("../config.php");

// Check login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$message = "";

if (isset($_POST['book'])) {

    $user_id = $_SESSION['user_id'];
    $doctor_id = $_POST['doctor_id'];
    $date = $_POST['date'];

    $query = "INSERT INTO appointments (user_id, doctor_id, appointment_date, status)
              VALUES ('$user_id', '$doctor_id', '$date', 'Pending')";

    if (mysqli_query($conn, $query)) {
        $message = "Appointment Booked Successfully!";
    } else {
        $message = "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Book Appointment</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

        body {
            background: linear-gradient(135deg, #1e3a8a, #2563eb);
            min-height: 100vh;
        }

        /* Navbar */
        .navbar {
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(10px);
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 22px;
            color: #fff !important;
        }

        /* Card Box */
        .box {
            background: white;
            padding: 30px;
            border-radius: 15px;
            margin-top: 60px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            animation: fadeIn 1s ease-in;
        }

        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Button */
        .btn-primary {
            background: linear-gradient(to right, #1e3a8a, #2563eb);
            border: none;
            font-weight: bold;
        }

        .btn-primary:hover {
            opacity: 0.9;
        }

    </style>
</head>

<body>

<!-- 🔝 Navbar -->
<nav class="navbar navbar-dark">
    <div class="container">
        <span class="navbar-brand">🩺 Smart Health System</span>
    </div>
</nav>

<div class="container">
    <div class="box">

        <h3 class="text-center mb-4 text-primary">📅 Book Appointment</h3>

        <?php if($message != "") { ?>
            <div class="alert alert-info"><?php echo $message; ?></div>
        <?php } ?>

        <form method="POST">

            <!-- Select Doctor -->
            <div class="mb-3">
                <label>Select Doctor</label>
                <select name="doctor_id" class="form-control" required>
                    <option value="">-- Select Doctor --</option>

                    <?php
                    $doctors = mysqli_query($conn, "SELECT * FROM doctors");

                    while ($row = mysqli_fetch_assoc($doctors)) {
                    ?>
                        <option value="<?php echo $row['doctor_id']; ?>">
                            <?php echo $row['name'] . " (" . $row['specialization'] . ")"; ?>
                        </option>
                    <?php } ?>

                </select>
            </div>

            <!-- Date -->
            <div class="mb-3">
                <label>Select Date</label>
                <input type="date" name="date" class="form-control" required>
            </div>

            <button type="submit" name="book" class="btn btn-primary w-100">
                Book Appointment
            </button>

        </form>

        <div class="text-center mt-3">
            <a href="dashboard.php" class="text-decoration-none text-primary">← Back to Dashboard</a>
        </div>

    </div>
</div>

</body>
</html>