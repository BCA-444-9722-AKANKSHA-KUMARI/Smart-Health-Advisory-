<?php
session_start();
include("../config.php");

// Check login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$result = "";

if (isset($_POST['predict'])) {

    if (!empty($_POST['symptoms'])) {

        $symptoms = $_POST['symptoms'];
        $symptom_ids = implode(",", $symptoms);

        $query = "
        SELECT d.disease_name, d.description, d.precautions, COUNT(ds.symptom_id) as match_count
        FROM disease_symptom ds
        JOIN diseases d ON ds.disease_id = d.disease_id
        WHERE ds.symptom_id IN ($symptom_ids)
        GROUP BY ds.disease_id
        ORDER BY match_count DESC
        LIMIT 1
        ";

        $res = mysqli_query($conn, $query);

        if (mysqli_num_rows($res) > 0) {
            $row = mysqli_fetch_assoc($res);

            $result = "
                <h4>Disease: {$row['disease_name']}</h4>
                <p><strong>Description:</strong> {$row['description']}</p>
                <p><strong>Precautions:</strong> {$row['precautions']}</p>
            ";
        } else {
            $result = "No matching disease found!";
        }

    } else {
        $result = "Please select symptoms!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Disease Prediction</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

        body {
            background: linear-gradient(135deg, #1e3a8a, #2563eb);
            min-height: 100vh;
        }

        /* Navbar */
        .navbar {
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(10px);
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 22px;
            color: #fff !important;
        }

        /* Card Box */
        .box {
            background: white;
            padding: 30px;
            border-radius: 15px;
            margin-top: 50px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            animation: fadeIn 1s ease-in;
        }

        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Checkbox hover */
        .form-check {
            padding: 8px;
            border-radius: 8px;
            transition: 0.3s;
        }

        .form-check:hover {
            background: #f1f5f9;
        }

        /* Button */
        .btn-success {
            background: linear-gradient(to right, #1e3a8a, #2563eb);
            border: none;
            font-weight: bold;
        }

        .btn-success:hover {
            opacity: 0.9;
        }

    </style>
</head>

<body>

<!-- 🔝 Navbar -->
<nav class="navbar navbar-dark">
    <div class="container">
        <span class="navbar-brand">🩺 Smart Health System</span>
    </div>
</nav>

<div class="container">
    <div class="box">

        <h3 class="text-center mb-4 text-primary">🧠 Select Your Symptoms</h3>

        <form method="POST">

            <div class="row">

                <?php
                $symptoms = mysqli_query($conn, "SELECT * FROM symptoms");

                while ($row = mysqli_fetch_assoc($symptoms)) {
                ?>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" 
                                   name="symptoms[]" value="<?php echo $row['symptom_id']; ?>">
                            <label class="form-check-label">
                                <?php echo $row['symptom_name']; ?>
                            </label>
                        </div>
                    </div>
                <?php } ?>

            </div>

            <div class="text-center mt-4">
                <button type="submit" name="predict" class="btn btn-success">
                    🔍 Predict Disease
                </button>
            </div>

        </form>

        <!-- RESULT -->
        <?php if($result != "") { ?>
            <div class="alert alert-info mt-4">
                <?php echo $result; ?>
            </div>
        <?php } ?>

    </div>
</div>

</body>
</html>