<?php
include("../config.php");

$message = "";

if (isset($_POST['register'])) {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];

    // ✅ Email Validation (PHP)
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Invalid Email Format!";
    } else {

        mysqli_query($conn, "INSERT INTO users (name, email, phone, password)
        VALUES ('$name','$email','$phone','$password')");

        $message = "Registration Successful!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            margin: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            font-family: Arial;
        }

        /* Navbar */
        .navbar {
            background: rgba(0,0,0,0.7);
            backdrop-filter: blur(10px);
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 22px;
            color: #fff !important;
        }

        /* MAIN */
        .main {
            display: flex;
            flex: 1;
        }

        /* LEFT SIDE */
        .left {
            width: 50%;
            background: linear-gradient(to bottom right, #1e3a8a, #2563eb);
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            text-align: center;
            animation: fadeIn 2s;
        }

        .left h1 {
            font-size: 40px;
        }

        /* RIGHT SIDE */
        .right {
            width: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #f0f7ff;
        }

        .register-box {
            width: 350px;
            animation: slideIn 1.5s;
        }

        @keyframes slideIn {
            from { transform: translateX(50px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* Inputs */
        .form-group {
            position: relative;
            margin-bottom: 20px;
        }

        .form-control {
            border-radius: 0;
            border: none;
            border-bottom: 2px solid #2563eb;
            background: transparent;
        }

        .form-control:focus {
            box-shadow: none;
            border-color: #1e3a8a;
        }

        label {
            position: absolute;
            top: -10px;
            left: 0;
            font-size: 12px;
            color: #2563eb;
        }

        /* Button */
        .btn-custom {
            background: linear-gradient(to right, #1e3a8a, #2563eb);
            color: white;
            font-weight: bold;
        }

        .btn-custom:hover {
            opacity: 0.9;
        }
    </style>
</head>

<body>

<!-- 🔝 Navbar -->
<nav class="navbar navbar-dark">
    <div class="container">
        <span class="navbar-brand">🩺 Smart Health System</span>
    </div>
</nav>

<div class="main">

<!-- LEFT PANEL -->
<div class="left">
    <h1>Join Smart Health</h1>
    <p>Register & manage your health easily</p>
    <i class="fa-solid fa-user-doctor fa-4x mt-3"></i>
</div>

<!-- RIGHT PANEL -->
<div class="right">

    <div class="register-box">

        <h3 class="text-center mb-4 text-primary">User Registration</h3>

        <?php if($message) { ?>
            <div class="alert alert-info"><?php echo $message; ?></div>
        <?php } ?>

        <form method="POST">

            <div class="form-group">
                <label>Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Phone</label>
                <input type="text" name="phone" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" id="pass" name="password" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" id="cpass" class="form-control" required>
            </div>

            <button name="register" class="btn btn-custom w-100">Register</button>

        </form>

        <p class="text-center mt-3">
            Already have account? <a href="login.php">Login</a>
        </p>

    </div>

</div>

</div>

<script>
// Password Match
document.querySelector("form").addEventListener("submit", function(e) {
    var p = document.getElementById("pass").value;
    var cp = document.getElementById("cpass").value;

    if (p !== cp) {
        alert("Passwords do not match!");
        e.preventDefault();
    }
});
</script>

</body>
</html>