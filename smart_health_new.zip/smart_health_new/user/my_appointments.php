<?php
session_start();
include("../config.php");

// Check login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Appointments</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

        body {
            background: linear-gradient(135deg, #1e3a8a, #2563eb);
            min-height: 100vh;
        }

        /* Navbar */
        .navbar {
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(10px);
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 22px;
            color: #fff !important;
        }

        /* Box */
        .box {
            background: white;
            padding: 25px;
            margin-top: 50px;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            animation: fadeIn 1s ease-in;
        }

        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Table Hover */
        table tbody tr:hover {
            background: #f1f5f9;
        }

    </style>
</head>

<body>

<!-- 🔝 Navbar -->
<nav class="navbar navbar-dark">
    <div class="container">
        <span class="navbar-brand">🩺 Smart Health System</span>
    </div>
</nav>

<div class="container">
    <div class="box">

        <h3 class="text-center mb-4 text-primary">📋 My Appointments</h3>

        <table class="table table-bordered text-center">
            <thead class="table-primary">
                <tr>
                    <th>Doctor Name</th>
                    <th>Specialization</th>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
            </thead>

            <tbody>

                <?php
                $query = "
                SELECT a.*, d.name, d.specialization
                FROM appointments a
                JOIN doctors d ON a.doctor_id = d.doctor_id
                WHERE a.user_id = '$user_id'
                ORDER BY a.appointment_id DESC
                ";

                $result = mysqli_query($conn, $query);

                if (mysqli_num_rows($result) > 0) {

                    while ($row = mysqli_fetch_assoc($result)) {
                ?>

                <tr>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['specialization']; ?></td>
                    <td><?php echo $row['appointment_date']; ?></td>
                    <td>
                        <span class="badge bg-warning text-dark">
                            <?php echo $row['status']; ?>
                        </span>
                    </td>
                </tr>

                <?php
                    }

                } else {
                    echo "<tr><td colspan='4'>No appointments found</td></tr>";
                }
                ?>

            </tbody>
        </table>

        <div class="text-center">
            <a href="dashboard.php" class="btn btn-secondary">Back</a>
        </div>

    </div>
</div>

</body>
</html>