<?php
session_start();
include("../config.php");

$message = "";

if (isset($_POST['login'])) {

    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM users WHERE email='$email' AND password='$password'");

    if (mysqli_num_rows($query) > 0) {
        $row = mysqli_fetch_assoc($query);
        $_SESSION['user_id'] = $row['user_id'];
        $_SESSION['name'] = $row['name'];

        header("Location: dashboard.php");
        exit();
    } else {
        $message = "Invalid Login!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Login</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            height: 100vh;
            margin: 0;
            background: linear-gradient(270deg, #6a11cb, #2575fc, #00c6ff);
            background-size: 600% 600%;
            animation: gradientBG 10s ease infinite;
            display: flex;
            flex-direction: column;
        }

        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* Navbar */
        .navbar {
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(10px);
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 22px;
            color: #fff !important;
        }

        /* Center Content */
        .main-container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-box {
            backdrop-filter: blur(15px);
            background: rgba(255,255,255,0.15);
            padding: 40px;
            border-radius: 15px;
            width: 350px;
            color: white;
            box-shadow: 0 0 20px rgba(0,0,0,0.3);
            animation: floatBox 3s ease-in-out infinite;
        }

        @keyframes floatBox {
            0%,100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }

        .form-control {
            background: transparent;
            color: white;
            border: 1px solid white;
        }

        .form-control::placeholder {
            color: #ddd;
        }

        .btn-custom {
            background: #fff;
            color: #333;
            font-weight: bold;
        }

        .btn-custom:hover {
            background: #ddd;
        }

        .icon {
            cursor: pointer;
            position: absolute;
            right: 15px;
            top: 10px;
            color: white;
        }

        .input-group {
            position: relative;
        }
    </style>
</head>

<body>

<!-- 🔝 Navbar -->
<nav class="navbar navbar-dark">
    <div class="container">
        <span class="navbar-brand">🩺 Smart Health System</span>
    </div>
</nav>

<!-- 🔐 Login Box -->
<div class="main-container">

<div class="login-box">

    <h3 class="text-center mb-4">User Login</h3>

    <?php if($message) { ?>
        <div class="alert alert-danger"><?php echo $message; ?></div>
    <?php } ?>

    <form method="POST">

        <div class="mb-3">
            <input type="email" name="email" class="form-control" placeholder="Email" required>
        </div>

        <div class="mb-3 input-group">
            <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
            <i class="fa fa-eye icon" onclick="togglePassword()"></i>
        </div>

        <button name="login" class="btn btn-custom w-100">Login</button>

    </form>

    <p class="text-center mt-3">
        Don't have an account? <a href="register.php" class="text-white">Register</a>
    </p>

</div>

</div>

<script>
function togglePassword() {
    var x = document.getElementById("password");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
</script>

</body>
</html>