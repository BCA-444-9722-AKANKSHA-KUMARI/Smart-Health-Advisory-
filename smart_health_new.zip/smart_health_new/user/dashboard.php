<?php
session_start();

$user = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : "User";
?>

<!DOCTYPE html>
<html>
<head>
<title>User Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

/* 🌈 Animated Background */
body {
    background: linear-gradient(-45deg, #3b82f6, #60a5fa, #93c5fd, #bfdbfe);
    background-size: 400% 400%;
    animation: bgMove 10s ease infinite;
}

@keyframes bgMove {
    0% {background-position: 0% 50%;}
    50% {background-position: 100% 50%;}
    100% {background-position: 0% 50%;}
}

/* Navbar */
.navbar {
    backdrop-filter: blur(10px);
    background: rgba(0,0,0,0.6);
}

/* Cards */
.card {
    border-radius: 20px;
    backdrop-filter: blur(10px);
    background: rgba(255,255,255,0.7);
    transition: 0.4s;
}

.card:hover {
    transform: translateY(-10px) scale(1.03);
    box-shadow: 0 15px 30px rgba(0,0,0,0.2);
}

/* Buttons */
.btn {
    border-radius: 25px;
    transition: 0.3s;
}

.btn:hover {
    transform: scale(1.1);
}

/* Icons */
.icon {
    font-size: 40px;
    margin-bottom: 10px;
}

/* Title animation */
h2 {
    animation: fadeIn 1s ease-in;
}

@keyframes fadeIn {
    from {opacity: 0; transform: translateY(20px);}
    to {opacity: 1; transform: translateY(0);}
}

</style>

</head>

<body>

<nav class="navbar navbar-dark">
    <div class="container">
        <span class="navbar-brand">💙 Smart Health</span>
        <div>
            <span class="text-white me-3">Welcome, <?php echo $user; ?></span>
            <a href="logout.php" class="btn btn-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-5">

<h2 class="text-center text-dark mb-5">User Dashboard</h2>

<div class="row text-center">

    <!-- Predict -->
    <div class="col-md-4 mb-4">
        <div class="card p-4">
            <div class="icon text-success">
                <i class="fa fa-heart-pulse"></i>
            </div>
            <h4>Predict Disease</h4>
            <p>Enter symptoms and get possible disease</p>
            <a href="predict.php" class="btn btn-success w-100">Start</a>
        </div>
    </div>

    <!-- Appointment -->
    <div class="col-md-4 mb-4">
        <div class="card p-4">
            <div class="icon text-primary">
                <i class="fa fa-calendar-check"></i>
            </div>
            <h4>Book Appointment</h4>
            <p>Schedule appointment with doctors</p>
            <a href="book_appointment.php" class="btn btn-primary w-100">Book Now</a>
        </div>
    </div>

    <!-- My Appointments -->
    <div class="col-md-4 mb-4">
        <div class="card p-4">
            <div class="icon text-warning">
                <i class="fa fa-list"></i>
            </div>
            <h4>My Appointments</h4>
            <p>View your appointment history</p>
            <a href="my_appointments.php" class="btn btn-warning w-100">View</a>
        </div>
    </div>

</div>

</div>

</body>
</html>